#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x14522340, "module_layout" },
	{ 0x5a34a45c, "__kmalloc" },
	{ 0x7ee91c1d, "_spin_trylock" },
	{ 0xf9a482f9, "msleep" },
	{ 0x6980fe91, "param_get_int" },
	{ 0x4417117a, "qdisc_reset" },
	{ 0xd2037915, "dev_set_drvdata" },
	{ 0x950ffff2, "cpu_online_mask" },
	{ 0xb4127d67, "dma_set_mask" },
	{ 0xd691cba2, "malloc_sizes" },
	{ 0xa30682, "pci_disable_device" },
	{ 0xf417ff07, "pci_disable_msix" },
	{ 0x865e3dca, "netif_carrier_on" },
	{ 0x973873ab, "_spin_lock" },
	{ 0x14ff9fcb, "ethtool_op_get_sg" },
	{ 0xa28e76e6, "schedule_work" },
	{ 0x43ab66c3, "param_array_get" },
	{ 0xf77cb70a, "netif_carrier_off" },
	{ 0x8d8708f, "cancel_work_sync" },
	{ 0xd3364703, "x86_dma_fallback_dev" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x6a9f26c9, "init_timer_key" },
	{ 0x1e5ed707, "pci_enable_wake" },
	{ 0xff964b25, "param_set_int" },
	{ 0x712aa29b, "_spin_lock_irqsave" },
	{ 0x3c2c5af5, "sprintf" },
	{ 0x45947727, "param_array_set" },
	{ 0x7d11c268, "jiffies" },
	{ 0x27c33efe, "csum_ipv6_magic" },
	{ 0x75484296, "netif_rx" },
	{ 0x9629486a, "per_cpu__cpu_number" },
	{ 0xfe7c4287, "nr_cpu_ids" },
	{ 0xaf559063, "pci_set_master" },
	{ 0xe83fea1, "del_timer_sync" },
	{ 0xde0bdcff, "memset" },
	{ 0x27773e78, "alloc_etherdev_mq" },
	{ 0x724781d5, "pci_enable_pcie_error_reporting" },
	{ 0xf12bb3b8, "dev_alloc_skb" },
	{ 0x7b3d21a1, "pci_enable_msix" },
	{ 0x621a5065, "pci_restore_state" },
	{ 0x8502d858, "dev_err" },
	{ 0xea147363, "printk" },
	{ 0xd4be820d, "ethtool_op_get_link" },
	{ 0x2fa5a500, "memcmp" },
	{ 0x7bd0a577, "free_netdev" },
	{ 0x7ec9bfbc, "strncpy" },
	{ 0xdb3b96d5, "register_netdev" },
	{ 0xb4390f9a, "mcount" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0xae290fb6, "pci_bus_write_config_dword" },
	{ 0x6dcaeb88, "per_cpu__kernel_stack" },
	{ 0x92ea4ae4, "crc32_le" },
	{ 0x4b07e779, "_spin_unlock_irqrestore" },
	{ 0x45450063, "mod_timer" },
	{ 0x1902adf, "netpoll_trap" },
	{ 0x859c6dc7, "request_threaded_irq" },
	{ 0x1615b190, "dev_kfree_skb_any" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0xef026125, "dev_kfree_skb_irq" },
	{ 0xd0a2dfa0, "pci_select_bars" },
	{ 0x7dceceac, "capable" },
	{ 0x3ff62317, "local_bh_disable" },
	{ 0x97377248, "netif_device_attach" },
	{ 0x9b3277f3, "_dev_info" },
	{ 0x78764f4e, "pv_irq_ops" },
	{ 0xb261ab5c, "netif_device_detach" },
	{ 0x42c8de35, "ioremap_nocache" },
	{ 0x89f397a9, "ethtool_op_set_sg" },
	{ 0xc5aa6d66, "pci_bus_read_config_dword" },
	{ 0x799aca4, "local_bh_enable" },
	{ 0xd55704ee, "eth_type_trans" },
	{ 0xf5f5d2d9, "pskb_expand_head" },
	{ 0x68f7c535, "pci_unregister_driver" },
	{ 0x2044fa9e, "kmem_cache_alloc_trace" },
	{ 0xfaf98462, "bitrev32" },
	{ 0xe52947e7, "__phys_addr" },
	{ 0xf4ff82f7, "pci_set_power_state" },
	{ 0xeacec774, "eth_validate_addr" },
	{ 0xe3b405a9, "pci_disable_pcie_error_reporting" },
	{ 0x3aa1dbcf, "_spin_unlock_bh" },
	{ 0x37a0cba, "kfree" },
	{ 0x236c8c64, "memcpy" },
	{ 0x1486c82b, "___pskb_trim" },
	{ 0x94a8242d, "pci_disable_msi" },
	{ 0xedc03953, "iounmap" },
	{ 0x5f07b9f3, "__pci_register_driver" },
	{ 0x4cbbd171, "__bitmap_weight" },
	{ 0x7b274cdb, "dev_warn" },
	{ 0x73618816, "unregister_netdev" },
	{ 0xcee83622, "ethtool_op_get_tso" },
	{ 0x6a7a886b, "pci_enable_msi_block" },
	{ 0x3961bdf6, "pci_choose_state" },
	{ 0xbc0d78f9, "__netif_schedule" },
	{ 0xde0cf25, "consume_skb" },
	{ 0x920d0bdd, "pci_enable_device_mem" },
	{ 0x93cbd1ec, "_spin_lock_bh" },
	{ 0x207b7e2c, "skb_put" },
	{ 0xb02504d8, "pci_set_consistent_dma_mask" },
	{ 0x77055215, "pci_release_selected_regions" },
	{ 0x74ee32f, "pci_request_selected_regions" },
	{ 0xa92a43c, "dev_get_drvdata" },
	{ 0x6e9681d2, "dma_ops" },
	{ 0xf20dabd8, "free_irq" },
	{ 0x717f16fa, "pci_save_state" },
	{ 0x92755db6, "__vlan_hwaccel_rx" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("pci:v00001969d00001063sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001062sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001073sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001083sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00002060sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00002062sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001091sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001090sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "4656D3E31911D483960A3EF");

static const struct rheldata _rheldata __used
__attribute__((section(".rheldata"))) = {
	.rhel_major = 6,
	.rhel_minor = 7,
	.rhel_release = 572,
};
